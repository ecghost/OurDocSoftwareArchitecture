# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..responses.response_output_refusal import ResponseOutputRefusal

__all__ = ["RefusalContent"]

RefusalContent = ResponseOutputRefusal
