# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from ..responses.response_input_file import ResponseInputFile

__all__ = ["InputFileContent"]

InputFileContent = ResponseInputFile
